#' Example data sets
#'
#' A list of AS, genes, transcripts and sample information matrix.
#'
#' @examples
#' data(ExDataSet)
#'
"ExDataSet"

